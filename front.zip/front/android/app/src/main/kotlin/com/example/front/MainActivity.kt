package com.example.front

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
